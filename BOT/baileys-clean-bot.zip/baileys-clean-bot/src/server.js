import express from 'express'
import { db } from './database.js'

const app = express()
const PORT = 3000

// Ruta para obtener consultas
app.get('/api/consultas', async (req, res) => {
  try {
    const { id } = req.params

    const [rows] = await db.query(`
      SELECT id, nombre, numero, fecha_creacion
      FROM consultas
      ORDER BY id DESC
    `)

    res.json(rows)
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: 'Error al obtener consultas' })
  }
})

app.get('/api/ticket/:id', async (req, res) => {
  try {
    const { id } = req.params

    const [rows] = await db.query(`
      SELECT mensaje, archivo, fecha
      FROM ticket
      WHERE consulta_id = ?
      ORDER BY id ASC
    `, [id])

    res.json(rows)
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: 'Error al obtener ticket' })
  }
})


// Servir la web estática
app.use(express.static('sitios_web'))

app.use('/uploads', express.static('src/uploads'))

app.listen(PORT, () => {
  console.log(`Web disponible en http://localhost:${PORT}`)
})
